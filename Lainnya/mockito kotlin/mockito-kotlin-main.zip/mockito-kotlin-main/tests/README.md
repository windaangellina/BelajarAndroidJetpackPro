Mockito-Kotlin tests
====================

Tests should be placed in this module.
CI is set up to execute tests for all major versions of Kotlin,
whilst keeping the library version on the latest version.  
This ensures the library is backwards compatible for all Kotlin versions.
