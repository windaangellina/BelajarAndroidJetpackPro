Thank you for submitting a pull request! But first:

 - [ ] Can you back your code up with tests?
 - [ ] Keep your commits clean: [squash your commits if necessary](https://git-scm.com/book/en/v2/Git-Tools-Rewriting-History).
