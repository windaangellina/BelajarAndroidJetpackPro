# Movie Catalogue Jetpack - Submission 2

Implementasi aplikasi katalog film menggunakan komponen Android Jetpack

> API KEY The Movie Database (TMDb) pada file gradle.properties perlu diisi.

# Demo

Download demo APK di [sini](https://gitlab.com/mramirid/movie-catalogue-jetpack-2/uploads/308014d4b5e38cfb3962c5b21529e63c/Movie_Catalogue_2.apk)