package com.example.submission1

abstract class NetworkBoundResource {
}