package com.example.submission1.db

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}