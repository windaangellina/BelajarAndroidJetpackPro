package com.example.submission1.room

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favoriteentities")
class FavoriteEntity (
    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "favID")
    var id: String,

    @ColumnInfo(name = "judul")
    var judul: String,

    @ColumnInfo(name = "isi")
    var isi: String,

    @ColumnInfo(name = "avatar")
    var avatar: String
)