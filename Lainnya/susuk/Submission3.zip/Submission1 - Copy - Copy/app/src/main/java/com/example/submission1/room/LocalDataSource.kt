package com.example.submission1.room

import androidx.lifecycle.LiveData

class LocalDataSource private constructor(private val dbDao: DBDao) {
    companion object {
        private var INSTANCE: LocalDataSource? = null

        fun getInstance(dbDao: DBDao): LocalDataSource =
            INSTANCE ?: LocalDataSource(dbDao)
    }

    fun getAll(): LiveData<List<FavoriteEntity>> = dbDao.getFavorite()

    suspend fun insertFavorite(favoriteEntity: FavoriteEntity){
        dbDao.insertFavorite(favoriteEntity)
    }

    suspend fun deleteFavorite(favoriteEntity: FavoriteEntity){
        dbDao.deleteFavorite(favoriteEntity)
    }
}