package com.gracielo.jetpacksubmission3vs.Data

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.FilmEntity
import com.gracielo.jetpacksubmission3v2.Data.FakeMovieCatalogueRepository
import com.gracielo.jetpacksubmission3v2.Data.Source.Remote.RemoteRepository
import com.gracielo.jetpacksubmission3v2.LiveDataTestUtil
import com.gracielo.jetpacksubmission3v2.Utils.DataDummyFilm
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.doAnswer
import com.nhaarman.mockitokotlin2.verify
import junit.framework.Assert.assertEquals
import org.junit.Assert
import org.junit.Rule
import org.junit.Test
import org.mockito.Mockito
import org.mockito.Mockito.mock
import org.mockito.invocation.InvocationOnMock


class MovieCatalogueRepositoryTest {
    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private val remote = mock(RemoteRepository::class.java)
    private val moviesRepository = FakeMovieCatalogueRepository(remote)
    private val moviesResponses = DataDummyFilm.generateRemoteMovies()
    private val TVResponses = DataDummyFilm.generateRemoteTV()
    private val movieId = moviesResponses[0].id
    private val tvId = TVResponses[0].id

    @Test
    fun getAllMovies() {
        doAnswer { invocation ->
            (invocation.arguments[0] as RemoteRepository.LoadItemsCallback)
                .onItemsReceived(moviesResponses)
            null
        }.`when`(remote).getMovies(any())
        val MoviesEntities = LiveDataTestUtil.getValue(moviesRepository.getMovies())
        verify(remote).getMovies(any())
        Assert.assertNotNull(MoviesEntities)
        assertEquals(moviesResponses.size.toLong(), MoviesEntities.size.toLong())
    }

    @Test
    fun getAllTV() {
        doAnswer { invocation ->
            (invocation.arguments[0] as RemoteRepository.LoadItemsCallback)
                .onItemsReceived(TVResponses)
            null
        }.`when`(remote).getTvShows(any())
        val TVShow = LiveDataTestUtil.getValue(moviesRepository.getTvShows())
        verify(remote).getTvShows(any())
        Assert.assertNotNull(TVShow)
        assertEquals(TVResponses.size.toLong(), TVShow.size.toLong())
    }

    @Test
    fun getItemMovies() {
        Mockito.doAnswer { invocation: InvocationOnMock ->
            (invocation.arguments[0] as RemoteRepository.LoadItemsCallback)
                .onItemsReceived(moviesResponses)
            null
        }.`when`(remote).getMovies(any())
        Mockito.doAnswer { invocation: InvocationOnMock ->
            (invocation.arguments[0] as RemoteRepository.LoadItemsCallback)
                .onItemsReceived(TVResponses)
            null
        }.`when`(remote).getTvShows(any())
        val movieResult: FilmEntity? = moviesRepository.getMovies().value?.get(0)
        val tvShowResult: FilmEntity? = moviesRepository.getTvShows().value?.get(0)
        Mockito.verify(remote, Mockito.times(1)).getMovies(any())
        Mockito.verify(remote, Mockito.times(1)).getTvShows(any())
        Assert.assertNotNull(movieResult)
        Assert.assertNotNull(tvShowResult)
        Assert.assertEquals(movieId.toLong(), movieResult!!.id!!.toLong())
        Assert.assertEquals(tvId.toLong(), tvShowResult!!.id!!.toLong())
    }
}