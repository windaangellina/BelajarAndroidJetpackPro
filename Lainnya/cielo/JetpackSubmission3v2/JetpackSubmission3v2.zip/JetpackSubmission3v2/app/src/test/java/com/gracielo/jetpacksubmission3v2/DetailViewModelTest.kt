package com.gracielo.jetpacksubmission3v2

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.gracielo.jetpacksubmission2.Data.Entity.FilmEntity
import com.gracielo.jetpacksubmission2.Data.Source.MovieCatalogueRepository
import com.gracielo.jetpacksubmission2.Detail.DetailViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class DetailViewModelTest {

    @Rule
    @JvmField
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var viewModel: DetailViewModel
    private val dummyMovie = DummyFilm.generateMovies()[0]
    private val dummyTvShow = DummyFilm.generateTV()[0]
    private val movieCatalogueRepository = Mockito.mock(MovieCatalogueRepository::class.java)


    @Before
    fun setUp() {
        viewModel = DetailViewModel(movieCatalogueRepository)

    }

    @Test
    fun GetFilm() {
        val movie = MutableLiveData<FilmEntity>()
        movie.setValue(dummyMovie)
        val movieId = dummyMovie!!.id
        Mockito.`when`(movieCatalogueRepository.getItem(FilmEntity.TYPE_MOVIE, movieId))
            .thenReturn(movie)
        viewModel.setItemId(movieId)
        viewModel.setItemType(FilmEntity.TYPE_MOVIE)
        val observer: Observer<FilmEntity?> =
            Mockito.mock(Observer::class.java) as Observer<FilmEntity?>
        viewModel!!.item.observeForever(observer)
        Mockito.verify(observer).onChanged(dummyMovie)
        val movieResult = viewModel!!.item.value
        assertNotNull(movieResult)
        assertEquals(dummyMovie.judul, movieResult!!.judul)
        assertEquals(dummyMovie.id, movieResult!!.id)
        assertEquals(dummyMovie.photo, movieResult!!.photo)
        assertEquals(dummyMovie.desc, movieResult!!.desc)
        assertEquals(dummyMovie.rating, movieResult!!.rating)
        assertEquals(dummyMovie.tahun, movieResult!!.tahun)
    }

    @Test
    fun GetTV() {
        val TV = MutableLiveData<FilmEntity>()
        TV.setValue(dummyTvShow)
        val tvID = dummyTvShow!!.id
        Mockito.`when`(movieCatalogueRepository.getItem(FilmEntity.TYPE_TV_SHOW, tvID))
            .thenReturn(TV)
        val observer: Observer<FilmEntity?> =
            Mockito.mock(Observer::class.java) as Observer<FilmEntity?>
        viewModel.setItemType(FilmEntity.TYPE_TV_SHOW)
        viewModel.setItemId(tvID)
        viewModel!!.item.observeForever(observer)
        Mockito.verify(observer).onChanged(dummyTvShow)
        val TVResult = viewModel!!.item.value
        assertNotNull(TVResult)
        assertEquals(dummyTvShow.judul, TVResult!!.judul)
        assertEquals(dummyTvShow.id, TVResult!!.id)
        assertEquals(dummyTvShow.photo, TVResult!!.photo)
        assertEquals(dummyTvShow.desc, TVResult!!.desc)
        assertEquals(dummyTvShow.rating, TVResult!!.rating)
        assertEquals(dummyTvShow.tahun, TVResult!!.tahun)
    }


}