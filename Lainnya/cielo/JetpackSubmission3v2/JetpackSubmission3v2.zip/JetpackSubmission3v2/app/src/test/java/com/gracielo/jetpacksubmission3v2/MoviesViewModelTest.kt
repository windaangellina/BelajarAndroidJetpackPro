package com.gracielo.jetpacksubmission3v2

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.gracielo.jetpacksubmission2.Data.Entity.FilmEntity
import com.gracielo.jetpacksubmission2.Data.Source.MovieCatalogueRepository
import com.gracielo.jetpacksubmission2.Movies.MoviesViewModel
import com.gracielo.jetpacksubmission2.Utils.DataDummyFilm
import com.nhaarman.mockitokotlin2.verify
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class MoviesViewModelTest {

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var viewModel: MoviesViewModel

    @Mock
    private val movieCatalogueRepository = Mockito.mock(MovieCatalogueRepository::class.java)

    @Mock
    private lateinit var observer: Observer<List<FilmEntity>>


    @Before
    fun setUp() {
        viewModel = MoviesViewModel(movieCatalogueRepository)
    }

    @Test
    fun testGetMovies() {
        val moviesList = DataDummyFilm.generateMovies()
        val movies = MutableLiveData<ArrayList<FilmEntity>>()
        movies.setValue(moviesList)
        Mockito.`when`(movieCatalogueRepository.getMovies()).thenReturn(movies)
        val observer: Observer<ArrayList<FilmEntity>> =
            Mockito.mock(Observer::class.java) as Observer<ArrayList<FilmEntity>>
        val movieEntities = viewModel.getMovies().value
        verify(movieCatalogueRepository).getMovies()
        assertNotNull(movieEntities)
        assertEquals(4, movieEntities?.size)

        viewModel.getMovies().observeForever(observer)
        verify(observer).onChanged(moviesList)
    }


}