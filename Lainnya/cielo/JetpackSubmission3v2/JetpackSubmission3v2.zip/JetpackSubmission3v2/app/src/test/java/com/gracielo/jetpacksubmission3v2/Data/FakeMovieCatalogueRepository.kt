package com.gracielo.jetpacksubmission3v2.Data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.FilmEntity
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.MovieEntity
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.TVEntity
import com.gracielo.jetpacksubmission3v2.Data.Source.FilmDataSource
import com.gracielo.jetpacksubmission3v2.Data.Source.Remote.RemoteRepository
import com.gracielo.jetpacksubmission3v2.Data.Source.Remote.Response.FilmResponse
import com.gracielo.jetpacksubmission3v2.Data.Source.Remote.Response.MovieResponse
import com.gracielo.jetpacksubmission3v2.Data.Source.Remote.Response.TVResponse
import java.util.*

class FakeMovieCatalogueRepository(private val remoteRepository: RemoteRepository) :
    FilmDataSource {
    override fun getMovies(): LiveData<ArrayList<MovieEntity>> {
        val movieResults: MutableLiveData<ArrayList<MovieEntity>> =
            MutableLiveData<ArrayList<MovieEntity>>()
        remoteRepository.getMovies(object : RemoteRepository.LoadMoviesCallback {
            override fun onItemsReceived(FilmResponses: ArrayList<MovieResponse>) {
                val movies: ArrayList<MovieEntity> = ArrayList<MovieEntity>()
                for (item in FilmResponses) {
                    val movie = MovieEntity(
                        item.id,
                        item.judul,
                        item.desc,
                        item.photo,
                        item.kategori,
                        item.tahun,
                        item.rating,
                        item.genre
                    )
                    movies.add(movie)
                }
                movieResults.postValue(movies)
            }


        })
        return movieResults
    }

    override fun getTvShows(): LiveData<ArrayList<TVEntity>> {
        val tvShowResults: MutableLiveData<ArrayList<TVEntity>> =
            MutableLiveData<ArrayList<TVEntity>>()
        remoteRepository.getTvShows(object : RemoteRepository.LoadTVCallback {
            override fun onItemsReceived(FilmResponses: ArrayList<TVResponse>) {
                val tvShows: ArrayList<TVEntity> = ArrayList<TVEntity>()
                for (item in FilmResponses) {
                    val tvShow = TVEntity(
                        item.id,
                        item.judul,
                        item.desc,
                        item.photo,
                        item.kategori,
                        item.tahun,
                        item.rating,
                        item.genre
                    )
                    tvShows.add(tvShow)
                }
                tvShowResults.postValue(tvShows)
            }
        })
        return tvShowResults
    }

    override fun getItem(itemType: String?, id: Int): LiveData<FilmEntity> {
        val itemResult: MutableLiveData<FilmEntity> = MutableLiveData<FilmEntity>()
        if (itemType == FilmEntity.TYPE_MOVIE) {
            remoteRepository.getMovies(object : RemoteRepository.LoadItemsCallback {
                override fun onItemsReceived(filmResponses: ArrayList<FilmResponse>) {
                    for (item in filmResponses) {
                        if (item.id === id) {
                            val movie = FilmEntity(
                                item.id,
                                item.judul,
                                item.desc,
                                item.photo,
                                item.kategori,
                                item.tahun,
                                item.rating,
                                item.genre
                            )
                            itemResult.postValue(movie)
                            break
                        }
                    }
                }

                override fun onDataNotAvailable() {
                    Log.e(
                        this.javaClass.simpleName,
                        "onDataNotAvailable: getItem: getMovies: Request failed"
                    )
                }
            })
        } else if (itemType == FilmEntity.TYPE_TV_SHOW) {
            remoteRepository.getTvShows(object : RemoteRepository.LoadItemsCallback {
                override fun onItemsReceived(filmResponses: ArrayList<FilmResponse>) {
                    for (item in filmResponses) {
                        if (item.id === id) {
                            val tvShow = FilmEntity(
                                item.id,
                                item.judul,
                                item.desc,
                                item.photo,
                                item.kategori,
                                item.tahun,
                                item.rating,
                                item.genre
                            )
                            itemResult.postValue(tvShow)
                            break
                        }
                    }
                }

                override fun onDataNotAvailable() {
                    Log.e(
                        this.javaClass.simpleName,
                        "onDataNotAvailable: getItem: getTvShows: Request failed"
                    )
                }
            })
        }
        return itemResult
    }

    companion object {
        @Volatile
        private var INSTANCE: FakeMovieCatalogueRepository? = null
        fun getInstance(remoteRepository: RemoteRepository): FakeMovieCatalogueRepository? {
            if (INSTANCE == null) {
                synchronized(FakeMovieCatalogueRepository::class.java) {
                    if (INSTANCE == null) INSTANCE =
                        FakeMovieCatalogueRepository(remoteRepository)
                }
            }
            return INSTANCE
        }
    }
}