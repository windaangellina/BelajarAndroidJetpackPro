package com.gracielo.jetpacksubmission3v2

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.gracielo.jetpacksubmission2.Data.Entity.FilmEntity
import com.gracielo.jetpacksubmission2.Data.Source.MovieCatalogueRepository
import com.gracielo.jetpacksubmission2.TV.TVViewModel
import com.gracielo.jetpacksubmission2.Utils.DataDummyFilm
import com.nhaarman.mockitokotlin2.verify
import org.junit.Assert
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito

class TVViewModelTest {
    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var viewModel: TVViewModel

    @Mock
    private val movieCatalogueRepository = Mockito.mock(MovieCatalogueRepository::class.java)


    @Before
    fun setUp() {
        viewModel = TVViewModel(movieCatalogueRepository)
    }

    @Test
    fun testGetTV() {
        val TVList = DataDummyFilm.generateTV()
        val TVs = MutableLiveData<ArrayList<FilmEntity>>()
        TVs.value = TVList
        Mockito.`when`(movieCatalogueRepository.getTvShows()).thenReturn(TVs)
        val observer: Observer<ArrayList<FilmEntity>> =
            Mockito.mock(Observer::class.java) as Observer<ArrayList<FilmEntity>>
        val TVEntities = viewModel.TV.value
        verify(movieCatalogueRepository).getTvShows()
        Assert.assertNotNull(TVEntities)
        Assert.assertEquals(2, TVEntities?.size)

        viewModel.TV.observeForever(observer)
        verify(observer).onChanged(TVList)
    }
}