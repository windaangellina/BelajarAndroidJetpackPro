package com.gracielo.jetpacksubmission3v2.Data.Source

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.MovieEntity
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.TVEntity
import com.gracielo.jetpacksubmission3v2.Data.Local.LocalDataSource
import com.gracielo.jetpacksubmission3v2.Data.NetworkBoundResource
import com.gracielo.jetpacksubmission3v2.Data.Source.Remote.ApiResponse
import com.gracielo.jetpacksubmission3v2.Data.Source.Remote.RemoteRepository
import com.gracielo.jetpacksubmission3v2.Data.Source.Remote.Response.MovieResponse
import com.gracielo.jetpacksubmission3v2.Data.Source.Remote.Response.TVResponse
import com.gracielo.jetpacksubmission3v2.Utils.AppExecutors
import com.gracielo.jetpacksubmission3v2.vo.Resource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

open class MovieCatalogueRepository private constructor(
    remoteRepository: RemoteRepository,
    private val localDataSource: LocalDataSource,
    private val appExecutors: AppExecutors
) : FilmDataSource {
    private val remoteRepository: RemoteRepository = remoteRepository

    companion object {
        @Volatile
        private var INSTANCE: MovieCatalogueRepository? = null
        fun getInstance(remoteRepository: RemoteRepository, localDataSource: LocalDataSource, appExecutors: AppExecutors): MovieCatalogueRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: MovieCatalogueRepository(remoteRepository, localDataSource, appExecutors).apply {
                    INSTANCE = this
                }
            }
    }

    override fun getMovies(): LiveData<Resource<List<MovieEntity>>> {
        return object : NetworkBoundResource<List<MovieEntity>, List<MovieResponse>>(appExecutors) {
            public override fun loadFromDB(): LiveData<List<MovieEntity>> = localDataSource.getListMovies()


            override fun shouldFetch(data: List<MovieEntity>?): Boolean =
                data == null || data.isEmpty()


            public override fun createCall(): LiveData<ApiResponse<List<MovieResponse>>> =
                remoteRepository.getMovies()

            public override fun saveCallResult(data: List<MovieResponse>) {
                val movieList = ArrayList<MovieEntity>()
                for (item in data) {
                    val movie = MovieEntity(
                        item.id,
                        item.judul,
                        item.desc,
                        item.photo,
                        item.kategori,
                        item.tahun,
                        item.rating,
                        item.genre,
                        false
                    )
                    movieList.add(movie)
                }
                localDataSource.insertMovies(movieList)
            }

        }.asLiveData()
    }

    override fun getListFavoriteMovies(): LiveData<List<MovieEntity>> {
        return localDataSource.getListFavoriteMovies()
    }

    override fun getTvShows(): LiveData<Resource<List<TVEntity>>> {
        return object : NetworkBoundResource<List<TVEntity>, List<TVResponse>>(appExecutors) {
            public override fun loadFromDB(): LiveData<List<TVEntity>> = localDataSource.getListTvShows()


            override fun shouldFetch(data: List<TVEntity>?): Boolean =
                data == null || data.isEmpty()


            public override fun createCall(): LiveData<ApiResponse<List<TVResponse>>> =
                remoteRepository.getTV()

            public override fun saveCallResult(data: List<TVResponse>) {
                val TVList = ArrayList<TVEntity>()
                for (item in data) {
                    val movie = TVEntity(
                        item.id,
                        item.judul,
                        item.desc,
                        item.photo,
                        item.kategori,
                        item.tahun,
                        item.rating,
                        item.genre,
                        false
                    )
                    TVList.add(movie)
                }
                localDataSource.insertTvShows(TVList)
            }

        }.asLiveData()
    }

    override fun getListFavoriteTvShows(): LiveData<List<TVEntity>> {
        return localDataSource.getListFavoriteTvShows()
    }

    override fun getItemTV(tvShowId: Int): LiveData<TVEntity> =
        localDataSource.getDetailTvShow(tvShowId)

    override fun getItemMovies(id: Int): LiveData<MovieEntity> =
        localDataSource.getDetailMovie(id)

    override fun setFavoriteMovie(movie: MovieEntity) {
        CoroutineScope(Dispatchers.IO).launch {
            localDataSource.setFavoriteMovie(movie)
        }
    }

    override fun setFavoriteTvShow(tvShow: TVEntity) {
        CoroutineScope(Dispatchers.IO).launch {
            localDataSource.setFavoriteTvShow(tvShow)
        }
    }




    
}