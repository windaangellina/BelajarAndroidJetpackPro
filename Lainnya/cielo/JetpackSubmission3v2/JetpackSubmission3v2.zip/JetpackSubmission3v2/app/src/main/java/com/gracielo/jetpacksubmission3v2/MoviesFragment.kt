package com.gracielo.jetpacksubmission3v2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.gracielo.jetpacksubmission3v2.Adapter.MovieAdapter
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.FilmEntity
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.MovieEntity
import com.gracielo.jetpacksubmission3v2.Movies.MoviesViewModel
import com.gracielo.jetpacksubmission3v2.databinding.FragmentMoviesBinding
import com.gracielo.jetpacksubmission3v2.vo.Resource
import java.util.*


class MoviesFragment : Fragment() {
    private lateinit var binding: FragmentMoviesBinding
    lateinit var adapter: MovieAdapter
    private lateinit var listMovies: LiveData<ArrayList<FilmEntity>>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentMoviesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        if (activity != null) {
            val viewModel = obtainViewModel(this)
            adapter = MovieAdapter(activity)
            viewModel.getMovies().observe(this, { itemEntities: Resource<List<MovieEntity>>? ->
                adapter.setItems(itemEntities!!.data)
                adapter.notifyDataSetChanged()
            })
            binding.rvMovies.setHasFixedSize(true)
            binding.rvMovies.layoutManager = LinearLayoutManager(context)
            binding.rvMovies.adapter = adapter
        }
    }

    private fun obtainViewModel(fragment: Fragment): MoviesViewModel {
        val factory: ViewModelFactory? = ViewModelFactory.getInstance(requireActivity())
        return ViewModelProvider(fragment, factory!!).get(MoviesViewModel::class.java)
    }


}