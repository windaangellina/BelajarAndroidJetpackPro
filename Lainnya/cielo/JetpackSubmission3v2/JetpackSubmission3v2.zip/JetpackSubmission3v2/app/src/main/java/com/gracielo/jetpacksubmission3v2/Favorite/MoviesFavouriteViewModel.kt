package com.gracielo.jetpacksubmission3v2.Favourite

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.FilmEntity
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.MovieEntity
import com.gracielo.jetpacksubmission3v2.Data.Source.MovieCatalogueRepository
import com.gracielo.jetpacksubmission3v2.vo.Resource

class MoviesFavouriteViewModel(movieCatalogueRepository: MovieCatalogueRepository) : ViewModel() {
    private val movieCatalogueRepository: MovieCatalogueRepository = movieCatalogueRepository

    fun getFavMovies(): LiveData<List<MovieEntity>> {
        return movieCatalogueRepository.getListFavoriteMovies()
    }

}