package com.gracielo.jetpacksubmission3v2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.gracielo.jetpacksubmission3v2.Adapter.TVAdapter
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.TVEntity
import com.gracielo.jetpacksubmission3v2.Film.Film
import com.gracielo.jetpacksubmission3v2.TV.TVViewModel
import com.gracielo.jetpacksubmission3v2.databinding.FragmentTvShowsBinding
import com.gracielo.jetpacksubmission3v2.vo.Resource

class TvShowsFragment : Fragment() {

    private lateinit var binding: FragmentTvShowsBinding
    lateinit var adapter: TVAdapter
    private lateinit var listTV: ArrayList<Film>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentTvShowsBinding.inflate(inflater, container, false)
        return binding.root
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        if (activity != null) {
            val viewModel = obtainViewModel(this)
            adapter = TVAdapter(activity)
            viewModel.TV.observe(this, { itemEntities: Resource<List<TVEntity>>? ->
                adapter.setItems(itemEntities!!.data)
                adapter.notifyDataSetChanged()
            })
            binding.rvTv.setHasFixedSize(true)
            binding.rvTv.layoutManager = LinearLayoutManager(context)
            binding.rvTv.adapter = adapter
        }
    }

    private fun obtainViewModel(fragment: Fragment): TVViewModel {
        val factory: ViewModelFactory? = ViewModelFactory.getInstance(requireActivity())
        return ViewModelProvider(fragment, factory!!).get(TVViewModel::class.java)
    }
}