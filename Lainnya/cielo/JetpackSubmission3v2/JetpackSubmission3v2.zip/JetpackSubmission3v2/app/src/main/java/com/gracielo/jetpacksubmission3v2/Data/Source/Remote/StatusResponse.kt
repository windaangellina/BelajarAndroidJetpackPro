package com.gracielo.jetpacksubmission3v2.Data.Source.Remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}