package com.gracielo.jetpacksubmission3v2.Favourite

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.gracielo.jetpacksubmission3v2.Adapter.FilmAdapter
import com.gracielo.jetpacksubmission3v2.Adapter.MovieAdapter
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.FilmEntity
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.MovieEntity
import com.gracielo.jetpacksubmission3v2.Movies.MoviesViewModel
import com.gracielo.jetpacksubmission3v2.R
import com.gracielo.jetpacksubmission3v2.ViewModelFactory
import com.gracielo.jetpacksubmission3v2.databinding.FragmentMoviesBinding
import com.gracielo.jetpacksubmission3v2.databinding.FragmentMoviesFavouriteBinding
import com.gracielo.jetpacksubmission3v2.vo.Resource


class MoviesFavourite : Fragment() {


    private var _binding : FragmentMoviesFavouriteBinding? = null
    lateinit var adapter: MovieAdapter
    private val binding get() = _binding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        _binding = FragmentMoviesFavouriteBinding.inflate(inflater, container, false)
        return (binding?.root)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        if(activity!=null){
            val viewModel = obtainViewModel(this)
            adapter = MovieAdapter(activity)
            viewModel.getFavMovies().observe(this, { itemEntities: List<MovieEntity>? ->
                adapter.setItems(itemEntities!!)
                adapter.notifyDataSetChanged()
            })
            binding?.rvMoviesFav?.setHasFixedSize(true)
            binding?.rvMoviesFav?.layoutManager = LinearLayoutManager(context)
            binding?.rvMoviesFav?.adapter = adapter
        }
    }


    private fun obtainViewModel(fragment: Fragment): MoviesFavouriteViewModel {
        val factory: ViewModelFactory? = ViewModelFactory.getInstance(requireActivity())
        return ViewModelProvider(fragment, factory!!).get(MoviesFavouriteViewModel::class.java)
    }
}