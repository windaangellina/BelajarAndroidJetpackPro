package com.gracielo.jetpacksubmission3v2.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}