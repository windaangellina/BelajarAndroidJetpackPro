package com.gracielo.jetpacksubmission3v2.Data.Source

import androidx.lifecycle.LiveData
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.MovieEntity
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.TVEntity
import com.gracielo.jetpacksubmission3v2.vo.Resource
import java.util.*

interface FilmDataSource {
    fun getMovies(): LiveData<Resource<List<MovieEntity>>>
    fun getListFavoriteMovies(): LiveData<List<MovieEntity>>

    fun getTvShows(): LiveData<Resource<List<TVEntity>>>
    fun getListFavoriteTvShows(): LiveData<List<TVEntity>>

    fun getItemMovies(id: Int): LiveData<MovieEntity>
    fun getItemTV(id: Int): LiveData<TVEntity>

    fun setFavoriteMovie(movie: MovieEntity)

    fun setFavoriteTvShow(tvShow: TVEntity)
}