package com.gracielo.jetpacksubmission3v2.Data.Local

import androidx.lifecycle.LiveData
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.MovieEntity
import com.gracielo.jetpacksubmission3v2.Data.Local.Entity.TVEntity
import com.gracielo.jetpacksubmission3v2.Data.Local.Room.FilmDao

class LocalDataSource constructor(private val filmDao: FilmDao) {

    companion object {
        private var INSTANCE: LocalDataSource? = null

        fun getInstance(filmDao: FilmDao): LocalDataSource =
            INSTANCE ?: LocalDataSource(filmDao)
    }

    fun getListMovies(): LiveData<List<MovieEntity>> = filmDao.getListMovies()

    fun getListFavoriteMovies(): LiveData<List<MovieEntity>> =
        filmDao.getListFavoriteMovies()

    fun getListTvShows(): LiveData<List<TVEntity>> = filmDao.getListTvShows()

    fun getListFavoriteTvShows(): LiveData<List<TVEntity>> =
        filmDao.getListFavoriteTvShows()

    fun getDetailMovie(movieId: Int): LiveData<MovieEntity> = filmDao.getDetailMovieById(movieId)

    fun getDetailTvShow(tvShowId: Int): LiveData<TVEntity> =
        filmDao.getDetailTvShowById(tvShowId)

    fun insertMovies(movies: List<MovieEntity>) = filmDao.insertMovies(movies)

    fun insertTvShows(tvShows: List<TVEntity>) = filmDao.insertTvShows(tvShows)

    fun setFavoriteMovie(movie: MovieEntity) {
        movie.isFavorite = !movie.isFavorite
        filmDao.updateMovie(movie)
    }

    fun setFavoriteTvShow(tvShow: TVEntity) {
        tvShow.isFavorite = !tvShow.isFavorite
        filmDao.updateTvShow(tvShow)
    }
}