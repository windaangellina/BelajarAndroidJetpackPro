package com.gracielo.jetpacksubmission3v2.Film


object DataFilm {

    fun generateMovies(): ArrayList<Film> {
        var MoviesList: ArrayList<Film> = ArrayList()
        return MoviesList
    }


    fun generateTV(): ArrayList<Film> {
        val TVList = ArrayList<Film>()
        return TVList
    }
}