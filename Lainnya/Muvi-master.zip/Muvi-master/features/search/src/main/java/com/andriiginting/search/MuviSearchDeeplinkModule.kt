package com.andriiginting.search

import com.airbnb.deeplinkdispatch.DeepLinkModule

@DeepLinkModule
class MuviSearchDeeplinkModule