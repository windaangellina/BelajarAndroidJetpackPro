package com.andriiginting.search.data

data class MuviSearchDataModel(
    val movieId: String,
    val movieBanner: String,
    val moviePoster: String,
    val movieTitle: String,
    val movieDescription: String
)
