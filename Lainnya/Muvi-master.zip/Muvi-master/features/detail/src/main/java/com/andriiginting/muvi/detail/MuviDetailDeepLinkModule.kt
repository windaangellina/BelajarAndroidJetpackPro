package com.andriiginting.muvi.detail

import com.airbnb.deeplinkdispatch.DeepLinkModule

@DeepLinkModule
class MuviDetailDeepLinkModule