package com.andriiginting.favorite

import com.airbnb.deeplinkdispatch.DeepLinkModule

@DeepLinkModule
class MuviFavoriteDeeplinkModule