package com.andriiginting.muvi

import com.airbnb.deeplinkdispatch.DeepLinkModule

@DeepLinkModule
class AppDeeplinkModule