package com.winda.couchpotato.data

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.winda.couchpotato.data.api.RetrofitClient
import com.winda.couchpotato.data.api.response.search.SearchMovieResponse
import com.winda.couchpotato.data.api.response.search.SearchTvShowsResponse
import com.winda.couchpotato.utils.DataDummy
import com.winda.couchpotato.utils.Event
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ShowsViewModel : ViewModel() {
    // repository
    private val repository : MovieDatabaseRepository = MovieDatabaseRepository()

    // list
    var listShowLiveData = MutableLiveData<ArrayList<Show>>()

    // api response
    private val _searchMovieResponse = MutableLiveData<Event<SearchMovieResponse>>()
    val searchMovieResponse : LiveData<Event<SearchMovieResponse>> = _searchMovieResponse

    private val _searchTvShowResponse = MutableLiveData<Event<SearchTvShowsResponse>>()
    val searchTvShowResponse : LiveData<Event<SearchTvShowsResponse>> = _searchTvShowResponse

    // status
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _errorCode = MutableLiveData<Int?>()
    val errorCode : LiveData<Int?> = _errorCode

    fun initResources(context: Context, categoryId : Int, filterByCategory : Boolean){
        val listShow = ArrayList<Show>()

        listShow.addAll(DataDummy.generateDataDummyFromResources(context, categoryId, filterByCategory))
        listShowLiveData.value = listShow
    }

    companion object{
        private const val TAG = "ShowsViewModel"
        private const val API_KEY = RetrofitClient.API_KEY
    }

    init {
        _isLoading.value = false
    }

    fun searchMovies(searchKeyword : String){
        _isLoading.value = true

        RetrofitClient.instanceMovieDatabaseApi.searchMovies(API_KEY, searchKeyword).enqueue(
            object : Callback<SearchMovieResponse> {
                override fun onResponse(
                    call: Call<SearchMovieResponse>,
                    response: Response<SearchMovieResponse>
                ) {
                    _isLoading.value = false

                    if (response.isSuccessful){
                        _searchMovieResponse.value = Event(response.body() as SearchMovieResponse)

                        //successful code
                        _errorCode.value = 200
                    }
                    else{
                        _errorCode.value = response.code()
                        Log.e(TAG, "onNotSuccessful movie response : ${response.message()}")
                    }
                }

                override fun onFailure(call: Call<SearchMovieResponse>, t: Throwable) {
                    _isLoading.value = false
                    Log.e(TAG, "onFailure movie response : ${t.message.toString()}")
                }
            }
        )
    }


    fun searchTvShows(searchKeyword: String){
        _isLoading.value = true

        RetrofitClient.instanceMovieDatabaseApi.searchTvShows(API_KEY, searchKeyword).enqueue(
            object : Callback<SearchTvShowsResponse> {
                override fun onResponse(
                    call: Call<SearchTvShowsResponse>,
                    response: Response<SearchTvShowsResponse>
                ) {
                    _isLoading.value = false

                    if (response.isSuccessful){
                        // _searchTvShowResponse.value = response.body()
                        _searchTvShowResponse.value = Event(response.body() as SearchTvShowsResponse)

                        //successful code
                        _errorCode.value = 200
                    }
                    else{
                        _errorCode.value = response.code()
                        Log.e(TAG, "onNotSuccessful tv shows response : ${response.message()}")
                    }
                }

                override fun onFailure(call: Call<SearchTvShowsResponse>, t: Throwable) {
                    _isLoading.value = false
                    Log.e(TAG, "onFailure tv shows response : ${t.message.toString()}")
                }

            }
        )
    }

//    fun getSearchMovieResponse(searchKeyword : String) : MutableLiveData<Any?> {
//        val searchMovieResponse = MutableLiveData<Any?>()
//
//        if (repository.getSearchMovieResponses(searchKeyword) !is SearchMovieResponse?) {
//            searchMovieResponse.postValue(repository.getSearchTvShowResponse(searchKeyword) as Int?)
//        } else {
//            searchMovieResponse.postValue(repository.getSearchMovieResponses(searchKeyword) as SearchMovieResponse?)
//        }
//        return searchMovieResponse
//    }
//
//    fun getSearchTvShowResponse(searchKeyword : String) : MutableLiveData<Any?> {
//        val searchTvShowResponse = MutableLiveData<Any?>()
//
//        if (repository.getSearchTvShowResponse(searchKeyword) !is SearchTvShowsResponse?){
//            searchTvShowResponse.postValue(repository.getSearchTvShowResponse(searchKeyword) as Int?)
//        }
//        else{
//            searchTvShowResponse.postValue(repository.getSearchTvShowResponse(searchKeyword) as SearchTvShowsResponse?)
//        }
//        return searchTvShowResponse
//    }
}