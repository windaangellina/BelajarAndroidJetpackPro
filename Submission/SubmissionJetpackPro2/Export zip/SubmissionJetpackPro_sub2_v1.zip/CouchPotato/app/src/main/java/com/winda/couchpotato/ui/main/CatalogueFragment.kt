package com.winda.couchpotato.ui.main

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.ArrayMap
import android.view.*
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat.getSystemService
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.winda.couchpotato.DetailActivity
import com.winda.couchpotato.R
import com.winda.couchpotato.adapter.RecyclerShowAdapter
import com.winda.couchpotato.data.Show
import com.winda.couchpotato.data.ShowsViewModel
import com.winda.couchpotato.data.api.response.search.SearchMovieResponse
import com.winda.couchpotato.data.api.response.search.SearchTvShowsResponse
import com.winda.couchpotato.databinding.FragmentCatalogueBinding
import java.lang.Exception
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList

class CatalogueFragment : Fragment() {
    // tab layout
    private lateinit var pageViewModel: PageViewModel
    private var categoryId : Int = -1

    // data
    private lateinit var binding: FragmentCatalogueBinding
    private lateinit var showsViewModel : ShowsViewModel
    private lateinit var showsAdapter : RecyclerShowAdapter

    // arguments
    private var tabTitle : String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            tabTitle = it.getString(ARG_TAB_TITLE).toString()
        }

        pageViewModel = ViewModelProvider(this).get(PageViewModel::class.java).apply {
            setIndex(arguments?.getInt(ARG_SECTION_NUMBER) ?: 1)
        }

        // get category
        // prepareResources(requireContext())
        categoryId = if (tabTitle.toLowerCase(Locale.ROOT) == "movies"){
            1
        }
        else{
            2
        }

//        showsViewModel = ViewModelProvider(this).get(ShowsViewModel::class.java).apply {
//            initResources(requireContext(), categoryId, true)
//        }

        showsViewModel = ViewModelProvider(this).get(ShowsViewModel::class.java)

//        initializeObservers()

        val listShow = ArrayList<Show>()
        when(categoryId){
            1 -> {
                showsViewModel.searchMovieResponse.observe(this, { event ->
                    event.getContentIfNotHandled().let { response ->
                        if (response != null) {
                            for (resultDetail in response.searchResultMovieResponses){
                                val userVote = resultDetail.voteAverage * 10
                                var releaseDate : LocalDate? = null
                                if (resultDetail.releaseDate.isNotEmpty()){
                                    releaseDate = getDate(resultDetail.releaseDate)
                                }

                                val show = Show(
                                    resultDetail.id,
                                    resultDetail.getPosterUrl(),
                                    resultDetail.getBackdropUrl(),
                                    resultDetail.title,
                                    releaseDate,
                                    userVote.toInt(),
                                    resultDetail.overview
                                )

                                if (show !in listShow){
                                    listShow.add(show)
                                }
                            }
                        }

                        showsAdapter.setListShows(listShow)
                    }

                })
            }
            else -> {
                showsViewModel.searchTvShowResponse.observe(this, { event ->
                    event.getContentIfNotHandled().let { response ->
                        if (response != null) {
                            for (resultDetail in response.searchResultTvShowResponses){
                                val userVote = resultDetail.voteAverage * 10
                                var releaseDate : LocalDate? = null

                                // run catching -> prevents crash when there is no first_air_date key in json result
                                kotlin.runCatching {
                                    if (resultDetail.firstAirDate != ""){
                                        releaseDate = getDate(resultDetail.firstAirDate)
                                    }
                                }.getOrNull()

                                val show = Show(
                                    resultDetail.id,
                                    resultDetail.getPosterUrl(),
                                    resultDetail.getBackdropUrl(),
                                    resultDetail.name,
                                    releaseDate,
                                    userVote.toInt(),
                                    resultDetail.overview
                                )

                                if (show !in listShow){
                                    listShow.add(show)
                                }
                            }
                        }

                        showsAdapter.setListShows(listShow)

                    }
                })
            }
        }

        showsViewModel.isLoading.observe(this, {
            binding.progressBar.visibility = if (it) View.VISIBLE else View.GONE
        })
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // untuk menampilkan option menu dari fragment
        setHasOptionsMenu(true)
        binding = FragmentCatalogueBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initRecyclerList()
    }

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"
        private const val ARG_TAB_TITLE = "tab_title"

        @JvmStatic
        fun newInstance(sectionNumber: Int, tabTitle : String): CatalogueFragment {
            return CatalogueFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_SECTION_NUMBER, sectionNumber)
                    putString(ARG_TAB_TITLE, tabTitle)
                }
            }
        }
    }

    private fun initializeObservers(){
        when(categoryId){
            1 -> observeMoviesList()
            else -> observeTvShowsList()
        }
        observeLoadingStatus()
    }

    private fun makeToast(pesan : String){
        Toast.makeText(requireContext(), pesan, Toast.LENGTH_SHORT).show()
    }

    private fun initRecyclerList(){
        // adapter
        showsAdapter = RecyclerShowAdapter()

        // set recycler
        binding.recyclerListShow.setHasFixedSize(true)
        binding.recyclerListShow.layoutManager = LinearLayoutManager(context)

        binding.recyclerListShow.adapter = showsAdapter

        // on click
        showsAdapter.setOnItemClickCallback(object : RecyclerShowAdapter.OnItemClickCallback{
            override fun onItemClickCallback(show: Show) {
                //makeToast(show.title)
                val detailIntent = Intent(context, DetailActivity::class.java)
                detailIntent.putExtra(DetailActivity.ARG_SHOW, show)
                startActivity(detailIntent)
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.option_search, menu)

        val searchManager = activity?.getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search)?.actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(activity?.componentName))
        searchView.queryHint = resources.getString(R.string.search_hint)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            /*
            Gunakan method ini ketika search selesai atau OK
             */
            override fun onQueryTextSubmit(query: String): Boolean {
                // Toast.makeText(activity?.applicationContext, query, Toast.LENGTH_SHORT).show()
                if (categoryId == 1){
                    // getSearchMovieResponse(query)
                    showsViewModel.searchMovies(query)
                }
                else{
                    // getSearchTvShowResponse(query)
                    showsViewModel.searchTvShows(query)
                }
                return true
            }

            /*
            Gunakan method ini untuk merespon tiap perubahan huruf pada searchView
             */
            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })

        super.onCreateOptionsMenu(menu, inflater)
    }

    private fun getDate(dateString : String) : LocalDate {
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        return LocalDate.parse(dateString, formatter)
    }

    private fun observeLoadingStatus(){
        makeToast("observe progress bar")
        showsViewModel.isLoading.observe(viewLifecycleOwner, {
            binding.progressBar.visibility = if (it) View.VISIBLE else View.GONE
        })
    }

    private fun observeMoviesList(){
        val listShow = ArrayList<Show>()
        makeToast("observe movies")

        showsViewModel.searchMovieResponse.observe(viewLifecycleOwner, { event ->
            event.getContentIfNotHandled().let { response ->
                if (response != null) {
                    for (resultDetail in response.searchResultMovieResponses){
                        val userVote = resultDetail.voteAverage * 10
                        var releaseDate : LocalDate? = null
                        if (resultDetail.releaseDate.isNotEmpty()){
                            releaseDate = getDate(resultDetail.releaseDate)
                        }

                        val show = Show(
                            resultDetail.id,
                            resultDetail.getPosterUrl(),
                            resultDetail.getBackdropUrl(),
                            resultDetail.title,
                            releaseDate,
                            userVote.toInt(),
                            resultDetail.overview
                        )

                        if (show !in listShow){
                            listShow.add(show)
                        }
                    }
                }

                showsAdapter.setListShows(listShow)
            }

        })
    }

    private fun observeTvShowsList(){
        val listShow = ArrayList<Show>()
        makeToast("observe tv shows")

        showsViewModel.searchTvShowResponse.observe(viewLifecycleOwner, { event ->
            event.getContentIfNotHandled().let { response ->
                if (response != null) {
                    for (resultDetail in response.searchResultTvShowResponses){
                        val userVote = resultDetail.voteAverage * 10
                        var releaseDate : LocalDate? = null

                        // run catching -> prevents crash when there is no first_air_date key in json result
                        kotlin.runCatching {
                            if (resultDetail.firstAirDate != ""){
                                releaseDate = getDate(resultDetail.firstAirDate)
                            }
                        }.getOrNull()

                        val show = Show(
                            resultDetail.id,
                            resultDetail.getPosterUrl(),
                            resultDetail.getBackdropUrl(),
                            resultDetail.name,
                            releaseDate,
                            userVote.toInt(),
                            resultDetail.overview
                        )

                        if (show !in listShow){
                            listShow.add(show)
                        }
                    }
                }

                showsAdapter.setListShows(listShow)

            }
        })
    }


//    private fun getSearchMovieResponse(searchKeyword : String){
//        val listShow = ArrayList<Show>()
//
//        showsViewModel.getSearchMovieResponse(searchKeyword).observe(viewLifecycleOwner, {
//            try {
//                val searchResponse = it as SearchMovieResponse?
//                if (searchResponse != null) {
//                    for (resultDetail in searchResponse.searchResultMovieResponses){
//                        val userVote = resultDetail.voteAverage * 100
//                        val show = Show(
//                            resultDetail.id,
//                            resultDetail.getPosterUrl(),
//                            resultDetail.getBackdropUrl(),
//                            resultDetail.title,
//                            getDate(resultDetail.releaseDate),
//                            userVote.toInt(),
//                            resultDetail.overview
//                        )
//
//                        if (show !in listShow){
//                            listShow.add(show)
//                        }
//                    }
//                }
//                else{
//                    makeToast("null data")
//                }
//
//                showsAdapter.setListShows(listShow)
//
//            } catch (e : Exception){
//                makeToast("search gagal : ${e.message}")
//            }
//        })
//    }
//
//
//    private fun getSearchTvShowResponse(searchKeyword: String){
//        val listShow = ArrayList<Show>()
//
//        showsViewModel.getSearchTvShowResponse(searchKeyword).observe(viewLifecycleOwner, {
//            if (it is SearchTvShowsResponse){
//                for (resultDetail in it.searchResultTvShowResponses){
//                    val userVote = resultDetail.voteAverage * 100
//                    val show = Show(
//                        resultDetail.id,
//                        resultDetail.getPosterUrl(),
//                        resultDetail.getBackdropUrl(),
//                        resultDetail.name,
//                        getDate(resultDetail.firstAirDate),
//                        userVote.toInt(),
//                        resultDetail.overview
//                    )
//
//                    if (show !in listShow){
//                        listShow.add(show)
//                    }
//                }
//
//                showsAdapter.setListShows(listShow)
//            }
//            else{
//                makeToast("search gagal. response code : $it")
//            }
//        })
//    }

}