package com.winda.couchpotato.utils

import com.winda.couchpotato.data.source.MovieDatabaseRepository
import com.winda.couchpotato.data.source.remote.RemoteDataSource

object Injection {
    fun provideMovieDatabaseRepository() : MovieDatabaseRepository{
        val remoteDataSource : RemoteDataSource = RemoteDataSource.getInstance(JsonHelper())
        return MovieDatabaseRepository.getInstance(remoteDataSource)
    }
}