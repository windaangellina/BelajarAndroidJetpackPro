package com.winda.couchpotato.data

class MovieDatabaseRepository() {

}