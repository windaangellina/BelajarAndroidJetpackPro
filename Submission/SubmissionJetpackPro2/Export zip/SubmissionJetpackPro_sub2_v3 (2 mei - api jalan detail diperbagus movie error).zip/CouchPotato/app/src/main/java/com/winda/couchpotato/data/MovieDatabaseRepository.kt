package com.winda.couchpotato.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.winda.couchpotato.data.api.MovieDatabaseApi
import com.winda.couchpotato.data.api.RetrofitClient
import com.winda.couchpotato.data.api.response.search.SearchMovieResponse
import com.winda.couchpotato.data.api.response.search.SearchTvShowsResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MovieDatabaseRepository() {
    // api response
    private val _searchMovieResponse = MutableLiveData<SearchMovieResponse>()
    val searchMovieResponse : LiveData<SearchMovieResponse> = _searchMovieResponse

    private val _searchTvShowResponse = MutableLiveData<SearchTvShowsResponse>()
    val searchTvShowResponse : LiveData<SearchTvShowsResponse> = _searchTvShowResponse

    // status
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _errorCode = MutableLiveData<Int>()
    val errorCode : LiveData<Int> = _errorCode

    companion object{
        private const val TAG = "MovieDatabaseRepository"
        private const val API_KEY = RetrofitClient.API_KEY
    }

    init {
        _isLoading.value = false
    }

    fun searchMovies(searchKeyword : String){
        _isLoading.value = true

        RetrofitClient.instanceMovieDatabaseApi.searchMovies(API_KEY, searchKeyword).enqueue(
            object : Callback<SearchMovieResponse>{
                override fun onResponse(
                    call: Call<SearchMovieResponse>,
                    response: Response<SearchMovieResponse>
                ) {
                    _isLoading.value = false

                    if (response.isSuccessful){
                        _searchMovieResponse.value = response.body()

                        //successful code
                        _errorCode.value = 200
                    }
                    else{
                        _errorCode.value = response.code()
                        Log.e(TAG, "onNotSuccessful movie response : ${response.message()}")
                    }
                }

                override fun onFailure(call: Call<SearchMovieResponse>, t: Throwable) {
                    _isLoading.value = false
                    Log.e(TAG, "onFailure movie response : ${t.message.toString()}")
                }
            }
        )
    }


    fun searchTvShows(searchKeyword: String){
        _isLoading.value = true

        RetrofitClient.instanceMovieDatabaseApi.searchTvShows(API_KEY, searchKeyword).enqueue(
            object : Callback<SearchTvShowsResponse>{
                override fun onResponse(
                    call: Call<SearchTvShowsResponse>,
                    response: Response<SearchTvShowsResponse>
                ) {
                    _isLoading.value = false

                    if (response.isSuccessful){
                        _searchTvShowResponse.value = response.body()

                        //successful code
                        _errorCode.value = 200
                    }
                    else{
                        _errorCode.value = response.code()
                        Log.e(TAG, "onNotSuccessful tv shows response : ${response.message()}")
                    }
                }

                override fun onFailure(call: Call<SearchTvShowsResponse>, t: Throwable) {
                    _isLoading.value = false
                    Log.e(TAG, "onFailure tv shows response : ${t.message.toString()}")
                }

            }
        )
    }


//    fun getSearchMovieResponses(searchKeyword : String) : Any? {
//        var searchMovieResponse : SearchMovieResponse? = null
//        var responseCode : Int? = null
//
//        RetrofitClient.instanceMovieDatabaseApi.searchMovies(apiKey, searchKeyword).enqueue(
//            object : Callback<SearchMovieResponse>{
//                override fun onResponse(call: Call<SearchMovieResponse>, response: Response<SearchMovieResponse>) {
//                    if (response.isSuccessful){
//                        response.body().let {
//                            it.also { searchMovieResponse = it }
//                        }
//                    }
//                    else{
//                        responseCode = response.code()
//                    }
//
//                    Log.d("searchSuccesful", "response movie : ${response.message()}")
//                }
//
//                override fun onFailure(call: Call<SearchMovieResponse>, t: Throwable) {
//                    Log.d("searchFailed", "search movie failed : ${t.message}")
//                }
//        })
//
//        if (searchMovieResponse != null){
//            return searchMovieResponse
//        }
//        else{
//            return responseCode
//        }
//
//    }
//
//    fun getSearchTvShowResponse(searchKeyword: String) : Any? {
//        var searchTvShowResponse : SearchTvShowsResponse? = null
//        var responseCode : Int? = null
//
//        RetrofitClient.instanceMovieDatabaseApi.searchTvShows(apiKey, searchKeyword).enqueue(
//            object : Callback<SearchTvShowsResponse>{
//                override fun onResponse(
//                    call: Call<SearchTvShowsResponse>,
//                    response: Response<SearchTvShowsResponse>
//                ) {
//                    if (response.isSuccessful){
//                        response.body().let {
//                            it.also { searchTvShowResponse = it}
//                        }
//                    }
//                    else{
//                        responseCode = response.code()
//                    }
//
//                    Log.d("searchSuccesful", "response tv show : ${response.message()}")
//                }
//
//                override fun onFailure(call: Call<SearchTvShowsResponse>, t: Throwable) {
//                    Log.d("searchFailed", "search tv shows failed : ${t.message}")
//                }
//            }
//        )
//
//        if (searchTvShowResponse != null){
//            return searchTvShowResponse
//        }
//        else{
//            return responseCode
//        }
//    }
}