package com.winda.couchpotato.data

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.eq
import com.nhaarman.mockitokotlin2.whenever
import com.winda.couchpotato.data.source.remote.RemoteDataSource
import com.winda.couchpotato.utils.DataDummy
import com.winda.couchpotato.utils.LiveDataUtils
import junit.framework.Assert.assertNotNull
import org.junit.Assert
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.*


class MovieDatabaseRepositoryTest {
    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private val remote = mock(RemoteDataSource::class.java)
    private val movieDatabaseRepository = FakeMovieDatabaseRepository(remote)

    // data dummy responses
    private val movieResponse = DataDummy.generateMoviesDataDummyResponse()
    private val judulMovie = movieResponse.searchResultMovieResponses[0].title
    private val tvResponse = DataDummy.generateTvShowsDataDummyResponse()
    private val judulTV = tvResponse.searchResultTvShowResponses[0].name

//    @Mock
//    private val callbackMovie = mock(RemoteDataSource.LoadMoviesCallback::class.java)


    @Test
    fun testGetSearchMoviesResult() {
        assertNotNull(movieResponse)

        doAnswer { invocation ->
            (invocation.arguments[1] as RemoteDataSource.LoadMoviesCallback)
                    .onItemsReceived(movieResponse)
            null
        }.`when`(remote).getSearchMovieResult(eq("avengers"), any())

//        whenever(remote.getSearchMovieResult(anyString(), any())).thenAnswer{
//            (it.arguments[1] as RemoteDataSource.LoadMoviesCallback).onItemsReceived(movieResponse)
//        }

        val movieLiveData = LiveDataUtils.getValue(movieDatabaseRepository.getSearchMoviesResult("avengers"))
        verify<RemoteDataSource>(remote).getSearchMovieResult(eq("avengers"), any())

        Assert.assertNotNull(movieLiveData)
    }

    @Test
    fun testGetSearchTvShowsResult() {
        assertNotNull(tvResponse)

        doAnswer { invocation ->
            (invocation.arguments[1] as RemoteDataSource.LoadTvShowsCallback)
                .onItemsReceived(tvResponse)
            null
        }.`when`(remote).getSearchTvShowResult(eq("vicenzo"), any())

        val tvLiveData = LiveDataUtils.getValue(movieDatabaseRepository.getSearchTvShowsResult("vincenzo"))
        verify<RemoteDataSource>(remote).getSearchTvShowResult(eq("vicenzo"),any())

        Assert.assertNotNull(tvLiveData)
    }
}