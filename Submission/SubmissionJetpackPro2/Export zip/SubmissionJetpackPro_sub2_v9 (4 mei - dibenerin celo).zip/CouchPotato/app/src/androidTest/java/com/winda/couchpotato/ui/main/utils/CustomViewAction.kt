package com.winda.couchpotato.ui.main.utils

import android.view.View
import androidx.appcompat.widget.SearchView
import androidx.test.espresso.ViewAction
import androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import org.hamcrest.CoreMatchers.allOf
import org.hamcrest.Matcher


object CustomViewAction {
    fun typeSearchViewText(query: String) : ViewAction {
        return object : ViewAction {
            override fun getConstraints(): Matcher<View> {
                //Ensure that only apply if it is a SearchView and if it is visible.
                return allOf(isDisplayed(), isAssignableFrom(SearchView::class.java))
            }

            override fun getDescription(): String {
                return "Change SearchView text"
            }

            override fun perform(uiController: androidx.test.espresso.UiController?, view: View?) {
                (view as SearchView).setQuery(query, true)
            }
        }
    }
}