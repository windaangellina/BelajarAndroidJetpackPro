package com.winda.submissionjetpackpro1.utils

import com.winda.submissionjetpackpro1.data.Show
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object DataDummy {
    fun generateDummyShows() : ArrayList<Show>{
        val shows = ArrayList<Show>()

        val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")
        val date = LocalDate.parse("10/01/2019", formatter)

        shows.add(Show(
            1, 1, 1, "hello world", 2, 15, date,
                "PG-13",98, "world is ours", "https://youtu.be/S12-4mXCNj4",
                "a journey on how to take over the world"
        ))

        shows.add(Show(
                2, 1, 1, "kotlin is the best", 2, 15, date,
                "PG-13",98, "kotlin is our best friend", "https://youtu.be/S12-4mXCNj4",
                "a movie for kotlin lovers"
        ))

        shows.add(Show(
                3, 1, 1, "hello world 2", 2, 15, date,
                "PG-13",98, "world is ours", "https://youtu.be/S12-4mXCNj4",
                "a journey on how to take over the world (the sequel)"
        ))

        return shows
    }
}