package com.winda.submissionjetpackpro1.ui.main

import androidx.fragment.app.testing.launchFragmentInContainer
import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.winda.submissionjetpackpro1.R
import com.winda.submissionjetpackpro1.utils.DataDummy
import junit.framework.TestCase
import org.junit.Test
import org.junit.runner.RunWith


@RunWith(AndroidJUnit4::class)
class CatalogueFragmentTest : TestCase(){
    private val dummyShows = DataDummy.generateDummyShows()

    @Test
    fun loadShows(){
        val scenario = launchFragmentInContainer<CatalogueFragment>()
        onView(withId(R.id.recyclerListShow)).check(matches(isDisplayed()))
        onView(withId(R.id.recyclerListShow)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyShows.size))
    }

    @Test
    fun loadShowsDetail(){
        val scenario = launchFragmentInContainer<CatalogueFragment>()
        onView(withId(R.id.recyclerListShow)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyShows.size))
        val show = dummyShows[0]

        assertNotNull(show)

        // simulate onItemClick
        onView(withId(R.id.recyclerListShow)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))

        // verify display status
        onView(withId(R.id.tvDetailJudul)).check(matches(isDisplayed()))
        onView(withId(R.id.tvTagline)).check(matches(isDisplayed()))
        onView(withId(R.id.tvDetailRatings)).check(matches(isDisplayed()))
        onView(withId(R.id.tvDetailUserScores)).check(matches(isDisplayed()))
        onView(withId(R.id.tvReleaseDate)).check(matches(isDisplayed()))
        onView(withId(R.id.tvOverview)).check(matches(isDisplayed()))
        onView(withId(R.id.tvDetailDuration)).check(matches(isDisplayed()))
        onView(withId(R.id.imgPoster)).check(matches(isDisplayed()))
    }
}