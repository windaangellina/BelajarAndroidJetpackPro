package com.winda.submissionjetpackpro1.data

import com.winda.submissionjetpackpro1.utils.DataDummy
import junit.framework.TestCase
import org.junit.Before
import org.junit.Test

class ShowsViewModelTest : TestCase() {

    private lateinit var showsViewModel: ShowsViewModel
    private val dummyShows = DataDummy.generateDummyShows()

    @Before
    override fun setUp(){
        showsViewModel = ShowsViewModel()
    }

    @Test
    fun testGetListShowLiveData() {
        val showsLiveData = showsViewModel.listShowLiveData
        assertNotNull(showsLiveData)
    }

    @Test
    fun testSetListShowLiveData() {
        val showsLiveData = showsViewModel.listShowLiveData
        showsLiveData.postValue(dummyShows)
    }
}