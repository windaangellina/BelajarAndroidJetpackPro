package com.winda.submissionjetpackpro1.data

import android.app.Application
import android.content.Context
import android.content.res.TypedArray
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.winda.submissionjetpackpro1.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList

class ShowsViewModel : ViewModel() {
    // list
    var listShowLiveData = MutableLiveData<ArrayList<Show>>()

    var listShow = ArrayList<Show>()
    private fun getDate(dateString : String) : LocalDate{
        val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")
        return LocalDate.parse(dateString, formatter)
    }

    fun initResources(categoryId : Int, filterByCategory : Boolean,
                      dataId : Array<String>,
                      dataCategoryId : Array<String>,
                      dataPoster : TypedArray,
                      dataTitle : Array<String>,
                      dataDurationHour : Array<String>,
                      dataDurationMinute : Array<String>,
                      dataReleaseDate : Array<String>,
                      dataUserScores : Array<String>,
                      dataRatings : Array<String>,
                      dataTagline : Array<String>,
                      dataTrailer : Array<String>,
                      dataOverview : Array<String>){
        listShow.clear()
        for (i in dataId.indices){
            val show = Show(
                    dataId[i].toInt(),
                    dataCategoryId[i].toInt(),
                    dataPoster.getResourceId(i, -1),
                    dataTitle[i],
                    dataDurationHour[i].toInt(),
                    dataDurationMinute[i].toInt(),
                    getDate(dataReleaseDate[i]),
                    dataRatings[i],
                    dataUserScores[i].toInt(),
                    dataTagline[i],
                    dataTrailer[i],
                    dataOverview[i]
            )

            var valid = true
            if (filterByCategory && categoryId != show.categoryId) {
                valid = false
            }

            if (valid) listShow.add(show)
        }

        listShowLiveData.value = listShow
    }
}