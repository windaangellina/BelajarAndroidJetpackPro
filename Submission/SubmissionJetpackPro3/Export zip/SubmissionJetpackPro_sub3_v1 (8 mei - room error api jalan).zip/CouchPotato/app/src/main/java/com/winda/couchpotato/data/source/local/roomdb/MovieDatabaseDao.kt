package com.winda.couchpotato.data.source.local.roomdb

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.winda.couchpotato.data.Show
import com.winda.couchpotato.utils.api.Event

@Dao
interface MovieDatabaseDao {
    @Query("select * from ${Show.TABLE_NAME}")
    fun getListFavorite() : LiveData<Event<List<Show>>>

    @Insert
    fun insertFavorite(show: Show)

    @Delete
    fun deleteFavorite(show: Show)
}