package com.winda.couchpotato.data.source.local

import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LiveData
import com.winda.couchpotato.data.Show
import com.winda.couchpotato.data.source.local.roomdb.MovieDatabaseDao
import com.winda.couchpotato.utils.api.Event

open class LocalDataSource(private val movieDatabaseDao: MovieDatabaseDao) {
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        @Volatile
        private var instance: LocalDataSource? = null

        fun getInstance(movieDatabaseDao: MovieDatabaseDao): LocalDataSource =
            instance ?: synchronized(this) {
                instance ?: LocalDataSource(movieDatabaseDao).apply { instance = this }
            }
    }

    fun getListFavorite() : LiveData<Event<List<Show>>>{
        return movieDatabaseDao.getListFavorite()
    }

    fun insertFavorite(show: Show){
        movieDatabaseDao.insertFavorite(show)
    }

    fun deleteFavorite(show: Show){
        movieDatabaseDao.deleteFavorite(show)
    }
}