package com.winda.couchpotato.data

import android.os.Parcelable
import androidx.annotation.Nullable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*

@Entity
@Parcelize
class Show (
        @PrimaryKey
        val id : Int,
        val posterUrl : String?,
        val backdropUrl : String?,
        val title: String,
        @Nullable
        private val releaseDate : LocalDate?,
        private val userScores : Int,
        val overview : String) : Parcelable {

    companion object {
        const val TABLE_NAME = "favorite_show"
    }

    fun getReleaseDateAsString() : String? {
        val formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.ENGLISH)
        return releaseDate?.format(formatter)
    }

    fun getUserScoresAsString() : String{
        return "$userScores %"
    }

    fun getTitleWithReleaseYear() : String{
        return if (releaseDate != null){
            "$title (${releaseDate.year})"
        } else{
            title
        }
    }


}